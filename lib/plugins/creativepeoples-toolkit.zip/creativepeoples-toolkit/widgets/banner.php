<?php  

class Banner extends \Elementor\Widget_Base {

    public function get_name() {
        return 'banner';
    }

    public function get_title() {
        return __( 'Banner', 'plugin-name' );
    }

    public function get_icon() {
        return 'fa fa-code';
    }

    public function get_categories() {
        return [ 'creativepeoples' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'plugin-name' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'banner_heaing',
            [
                'label' => __( 'Banner Heading', 'plugin-name' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings_for_display();

?>

        <!-- html goes here -->
        <h1><?php echo $settings['banner_heaing']; ?></h1>
        <!-- html goes here -->

<?php

    }

}